/*
 Navicat Premium Data Transfer

 Source Server         : mysql
 Source Server Type    : MySQL
 Source Server Version : 50639
 Source Host           : localhost:3306
 Source Schema         : sboot_tsglxt

 Target Server Type    : MySQL
 Target Server Version : 50639
 File Encoding         : 65001

 Date: 19/04/2021 14:19:55
*/

drop database if exists sboot_tsglxt;
create database sboot_tsglxt charset utf8;
use sboot_tsglxt;

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for admin
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `adminid` varchar(32) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `realname` varchar(50) DEFAULT NULL,
  `contact` varchar(50) DEFAULT NULL,
  `addtime` varchar(28) DEFAULT NULL,
  PRIMARY KEY (`adminid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of admin
-- ----------------------------
BEGIN;
INSERT INTO `admin` VALUES ('A20210331012658725', 'admin', 'admin', 'admin', '13888888888', '2021-05-09');
INSERT INTO `admin` VALUES ('A20210406043436119', 'tom', '111', '汤姆', '1399999999', '2021-05-09');
INSERT INTO `admin` VALUES ('A20210406043442958', 'jack', '222', '杰克', '13666666666', '2021-05-09');
COMMIT;

-- ----------------------------
-- Table structure for applys
-- ----------------------------
DROP TABLE IF EXISTS `applys`;
CREATE TABLE `applys` (
  `applysid` varchar(32) NOT NULL,
  `ordersid` varchar(32) DEFAULT NULL,
  `usersid` varchar(32) DEFAULT NULL,
  `booksid` varchar(32) DEFAULT NULL,
  `reason` varchar(50) DEFAULT NULL,
  `addtime` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `memo` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`applysid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of applys
-- ----------------------------
BEGIN;
INSERT INTO `applys` VALUES ('A20210406034522543', 'O20210406031730639', 'U20210406031719347', 'B20210331090907149', '123123', '2021-05-09', '通过审核', '234234');
INSERT INTO `applys` VALUES ('A20210406044054375', 'O20210406043920233', 'U20210406043850769', 'B20210331090930530', '123123', '2021-05-09', '通过审核', '123123');
COMMIT;

-- ----------------------------
-- Table structure for article
-- ----------------------------
DROP TABLE IF EXISTS `article`;
CREATE TABLE `article` (
  `articleid` varchar(32) NOT NULL,
  `title` varchar(50) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `contents` text,
  `addtime` varchar(28) DEFAULT NULL,
  `hits` int(11) DEFAULT NULL,
  PRIMARY KEY (`articleid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of article
-- ----------------------------
BEGIN;
INSERT INTO `article` VALUES ('A20210419135141283', '举办图书管理员培训 助推书香校园建设', 'upfiles/20210419135135.jpeg', '<div class=\"index-module_textWrap_3ygOc\" style=\"color: rgb(0, 0, 0); font-family: arial; font-size: 12px;\">\r\n<p style=\"text-align:justify\">为强化我州学校图书管理人员业务素养，进一步提升业务水平，充分发挥学校图书馆的育人功能，4月9日，在州教育局八楼会议室举办了&ldquo;2021年临夏州学校图书馆管理人员培训&rdquo;。培训会由临夏州教育局、州文化广电和旅游局主办，州图书馆承办。甘肃省图书馆许新龙馆长、州文化广电和旅游局党组成员、州歌舞团团长王丽华、州图书馆馆长王晓黎、州教育局分管领导、各县市教育局装备办、部分学校图书馆管理人员、州教育局装备办全体共计100余人参加了培训会。</p>\r\n</div>\r\n\r\n<div class=\"index-module_mediaWrap_213jB\" style=\"display: flex; margin-top: 36px; color: rgb(0, 0, 0); font-family: arial; font-size: 12px;\">\r\n<div class=\"index-module_contentImg_JmmC0\" style=\"display: flex; -webkit-box-orient: vertical; -webkit-box-direction: normal; flex-direction: column; -webkit-box-align: center; align-items: center; width: 599px;\"><img class=\"index-module_large_1mscr\" src=\"https://pics1.baidu.com/feed/0bd162d9f2d3572c4fb4ec79b8bb312f63d0c375.jpeg?token=836a9fce20eed77029475dab3333e6d0\" style=\"border-radius:13px; border:0px; width:599px\" /></div>\r\n</div>\r\n\r\n<div class=\"index-module_textWrap_3ygOc\" style=\"margin-top: 36px; color: rgb(0, 0, 0); font-family: arial; font-size: 12px;\">\r\n<p style=\"text-align:justify\">上午，省图书馆古保中心徐双定主任以公共图书馆未成年人服务为专题做了培训；兰州市陇之脊文化传播有限公司高祥经理从分析图书馆发展现状、管理现状、借还方式、未来发展等方面做了专题培训；下午，全体培训人员到临夏州图书馆进行了现场观摩学习。</p>\r\n</div>\r\n\r\n<div class=\"index-module_mediaWrap_213jB\" style=\"display: flex; margin-top: 36px; color: rgb(0, 0, 0); font-family: arial; font-size: 12px;\">\r\n<div class=\"index-module_contentImg_JmmC0\" style=\"display: flex; -webkit-box-orient: vertical; -webkit-box-direction: normal; flex-direction: column; -webkit-box-align: center; align-items: center; width: 599px;\"><img class=\"index-module_large_1mscr\" src=\"https://pics6.baidu.com/feed/38dbb6fd5266d016ee0dc615a083860f35fa3523.jpeg?token=013b0ad08ed7224f353fdf7cc449b59d\" style=\"border-radius:13px; border:0px; width:599px\" /></div>\r\n\r\n<div>&nbsp;</div>\r\n</div>\r\n', '2021-05-09', 0);
INSERT INTO `article` VALUES ('A20210419135330623', '图书馆开“跳蚤市集”，换书大会好热闹', 'upfiles/20210419135326.jpeg', '<div class=\"index-module_textWrap_3ygOc\" style=\"margin-top: 22px; color: rgb(0, 0, 0); font-family: arial; font-size: 12px;\">\r\n<p style=\"text-align:justify\">第26个&ldquo;世界读书日&rdquo;到来之际，4月18日，&ldquo;书香泉城&rdquo;暨第十一届书香泉城&middot;全民阅读节热场活动之一暨济南市图书馆第六届&ldquo;书香童趣&rdquo;跳蚤市集及少儿换书活动在在济南市图书馆外广场举行。</p>\r\n</div>\r\n\r\n<div class=\"index-module_mediaWrap_213jB\" style=\"display: flex; margin-top: 36px; color: rgb(0, 0, 0); font-family: arial; font-size: 12px;\">\r\n<div class=\"index-module_contentImg_JmmC0\" style=\"display: flex; -webkit-box-orient: vertical; -webkit-box-direction: normal; flex-direction: column; -webkit-box-align: center; align-items: center; width: 599px;\"><img class=\"index-module_large_1mscr\" src=\"https://pics3.baidu.com/feed/6a600c338744ebf8a1b4dade7e2489226259a774.jpeg?token=5772635a497f06826f9451febb825451\" style=\"border-radius:13px; border:0px; width:599px\" /></div>\r\n</div>\r\n\r\n<div class=\"index-module_mediaWrap_213jB\" style=\"display: flex; margin-top: 40px; color: rgb(0, 0, 0); font-family: arial; font-size: 12px;\">\r\n<div class=\"index-module_contentImg_JmmC0\" style=\"display: flex; -webkit-box-orient: vertical; -webkit-box-direction: normal; flex-direction: column; -webkit-box-align: center; align-items: center; width: 599px;\"><img class=\"index-module_large_1mscr\" src=\"https://pics7.baidu.com/feed/48540923dd54564ea134b53d1d3ec28ad0584f4d.jpeg?token=58221c2ef2c4a32dc4a6bdff0cfe8f8c\" style=\"border-radius:13px; border:0px; width:599px\" /></div>\r\n</div>\r\n\r\n<div class=\"index-module_textWrap_3ygOc\" style=\"margin-top: 36px; color: rgb(0, 0, 0); font-family: arial; font-size: 12px;\">\r\n<p style=\"text-align:justify\">来自济南市胜利大街小学、大金小学、恒新小学、阳光100小学、博文小学、饮马小学等校的300余组家庭参与了此次活动。当天，孩子们一早就来到活动现场，以学校为单位，领取&ldquo;营业执照&rdquo;，陆续找到自己的摊位。闲置的图书、玩具、各类文具迅速被铺展开来，以物易物，以书易物，有的摊位很快被&ldquo;抢购&rdquo;一空。欢声笑语，你来我往，孩子们交换着欢乐，传递着友情，分享着以阅读为&ldquo;媒介&rdquo;带来的成就感。</p>\r\n</div>\r\n\r\n<div class=\"index-module_mediaWrap_213jB\" style=\"display: flex; margin-top: 36px; color: rgb(0, 0, 0); font-family: arial; font-size: 12px;\">\r\n<div class=\"index-module_contentImg_JmmC0\" style=\"display: flex; -webkit-box-orient: vertical; -webkit-box-direction: normal; flex-direction: column; -webkit-box-align: center; align-items: center; width: 599px;\"><img class=\"index-module_large_1mscr\" src=\"https://pics0.baidu.com/feed/c9fcc3cec3fdfc03fd8680467de2d99ca6c226b3.jpeg?token=9f513d5f6753eda29e8f0fb3fe3d5fba\" style=\"border-radius:13px; border:0px; width:599px\" /></div>\r\n\r\n<div>&nbsp;</div>\r\n</div>\r\n\r\n<div class=\"index-module_mediaWrap_213jB\" style=\"display: flex; margin-top: 40px; color: rgb(0, 0, 0); font-family: arial; font-size: 12px;\">&nbsp;</div>\r\n', '2021-05-09', 1);
INSERT INTO `article` VALUES ('A20210419135440272', '好消息！图书馆即将全面开放', 'upfiles/20210419135437.jpeg', '<p>阳光正暖，书香满室。</p>\r\n\r\n<p>昨日下午，</p>\r\n\r\n<p>记者来到位于晋江东石镇的</p>\r\n\r\n<p>&ldquo;母亲的房子&rdquo;图书馆，</p>\r\n\r\n<p>三三两两的孩子，</p>\r\n\r\n<p>正在安静闲适的图书馆里，畅游书海。</p>\r\n\r\n<p>受疫情影响</p>\r\n\r\n<p>暂时闭馆的&ldquo;母亲的房子&rdquo;图书馆，</p>\r\n\r\n<p>昨日重新开放，</p>\r\n\r\n<p>目前进入试运营阶段。</p>\r\n\r\n<p><img class=\"content-picture\" src=\"https://inews.gtimg.com/newsapp_bt/0/13424953998/1000\" style=\"border:0px none; display:block; margin:0.6em auto; max-width:100%; vertical-align:middle\" /></p>\r\n\r\n<p>试运营期间，</p>\r\n\r\n<p>图书馆开放时间为</p>\r\n\r\n<p>每周三、周四的上午10时至下午6时，</p>\r\n\r\n<p>周五至周日上午10时至晚上9时。</p>\r\n', '2021-05-09', 1);
COMMIT;

-- ----------------------------
-- Table structure for books
-- ----------------------------
DROP TABLE IF EXISTS `books`;
CREATE TABLE `books` (
  `booksid` varchar(32) NOT NULL,
  `isbn` varchar(50) DEFAULT NULL,
  `booksname` varchar(50) DEFAULT NULL,
  `cateid` varchar(32) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `author` varchar(50) DEFAULT NULL,
  `publisher` varchar(50) DEFAULT NULL,
  `recommend` varchar(10) DEFAULT NULL,
  `addtime` varchar(28) DEFAULT NULL,
  `hits` int(11) DEFAULT NULL,
  `storage` varchar(50) DEFAULT NULL,
  `num` int(11) DEFAULT NULL,
  `contents` text,
  PRIMARY KEY (`booksid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of books
-- ----------------------------
BEGIN;
INSERT INTO `books` VALUES ('B20210331023442874', '123123', 'S. 忒修斯之船', 'C20210331023300258', 'upfiles/20210331023425.jpg', 'S. 忒修斯之船', 'S. 忒修斯之船', '是', '2021-05-09', 0, '10', 0, '<p>S. 忒修斯之船 （简体中文典藏复刻版）</p>\r\n');
INSERT INTO `books` VALUES ('B20210331025728600', 'ISBN20210331025707', '必须牺牲卡米尔', 'C20210331023300258', 'upfiles/20210331025719.jpg', '12312', '必须牺牲卡米尔', '是', '2021-05-09', 0, '10', 0, '<p>必须牺牲卡米尔必须牺牲卡米尔必须牺牲卡米尔</p>\r\n');
INSERT INTO `books` VALUES ('B20210331025748703', 'ISBN20210331025728', '大冰套装', 'C20210331023300258', 'upfiles/20210331025735.jpg', '大冰套装', '大冰套装', '是', '2021-05-09', 0, '10', 0, '<p>大冰套装：么么哒+摸摸头+好吗好的+我不（套装共4册）</p>\r\n');
INSERT INTO `books` VALUES ('B20210331025814921', 'ISBN20210331025748', '永夜君王', 'C20210331023300258', 'upfiles/20210331025805.jpg', '永夜君王', '永夜君王', '是', '2021-05-09', 0, '10', 0, '<p>永夜君王永夜君王永夜君王</p>\r\n');
INSERT INTO `books` VALUES ('B20210331025904674', 'ISBN20210331025814', '帝国重器', 'C20210331023300258', 'upfiles/20210331025856.jpg', '帝国重器', '帝国重器', '是', '2021-05-09', 0, '10', 0, '<p>帝国重器帝国重器帝国重器帝国重器帝国重器</p>\r\n');
INSERT INTO `books` VALUES ('B20210331025925508', 'ISBN20210331025904', '凡人修仙传', 'C20210331023300258', 'upfiles/20210331025913.jpg', '凡人修仙传', '凡人修仙传', '是', '2021-05-09', 0, '10', 0, '<p>凡人修仙传凡人修仙传凡人修仙传凡人修仙传</p>\r\n\r\n<p>凡人修仙传凡人修仙传凡人修仙传凡人修仙传</p>\r\n\r\n<p>凡人修仙传凡人修仙传凡人修仙传凡人修仙传</p>\r\n');
INSERT INTO `books` VALUES ('B20210331030819199', 'ISBN20210331030743', '小饼干自然拼读法 ', 'C20210331030740237', 'upfiles/20210331030759.jpg', '小饼干自然拼读法', '小饼干自然拼读法 ', '是', '2021-05-09', 0, '10', 0, '<p>Biscuit Phonics Fun (My First I Can Read)小饼干自然拼读法 英文原版</p>\r\n');
INSERT INTO `books` VALUES ('B20210331030836809', 'ISBN20210331030819', '想成为我的朋友吗', 'C20210331030740237', 'upfiles/20210331030825.jpg', '想成为我的朋友吗', '想成为我的朋友吗', '是', '2021-05-09', 0, '10', 0, '<p>Do You Want to Be My Friend 想成为我的朋友吗 英文原版</p>\r\n');
INSERT INTO `books` VALUES ('B20210331030854705', 'ISBN20210331030836', '《青蛙和蟾蜍》', 'C20210331030740237', 'upfiles/20210331030842.jpg', '《青蛙和蟾蜍》', '《青蛙和蟾蜍》', '是', '2021-05-09', 0, '10', 0, '<p>Frog and Toad Storybook Treasury 《青蛙和蟾蜍》故事合集 英文原版</p>\r\n');
INSERT INTO `books` VALUES ('B20210331030916989', 'ISBN20210331030854', '寻宝小子', 'C20210331030740237', 'upfiles/20210331030901.jpg', '寻宝小子', '寻宝小子', '是', '2021-05-09', 0, '10', 0, '<p>holes原版小说 寻宝小子 英文原版</p>\r\n');
INSERT INTO `books` VALUES ('B20210331031040346', 'ISBN20210331030916', '孤独星球旅行指南', 'C20210331030740237', 'upfiles/20210331031029.jpg', '孤独星球旅行指南', '孤独星球旅行指南', '是', '2021-05-09', 0, '10', 0, '<p>Lonely Planet Italy (Country Guide)孤独星球旅行指南 意大利 英文原版</p>\r\n');
INSERT INTO `books` VALUES ('B20210331031106440', 'ISBN20210331031040', '杀死一只知更鸟', 'C20210331030740237', 'upfiles/20210331031051.jpg', '杀死一只知更鸟', '杀死一只知更鸟', '是', '2021-05-09', 0, '10', 0, '<p>To Kill a Mockingbird 杀死一只知更鸟 英文原版</p>\r\n');
INSERT INTO `books` VALUES ('B20210331031126440', 'ISBN20210331031106', '消失的爱人', 'C20210331030740237', 'upfiles/20210331031115.jpg', '消失的爱人', '消失的爱人', '是', '2021-05-09', 0, '10', 0, '<p>Gone Girl&nbsp; A Novel消失的爱人 英文原版</p>\r\n');
INSERT INTO `books` VALUES ('B20210331090754119', 'ISBN20210331090726', 'Effective Java中文版', 'C20210331090716316', 'upfiles/20210331090739.jpg', '吴宛康', '《青蛙和蟾蜍》', '是', '2021-05-09', 0, '10', 0, '<p>Effective Java中文版</p>\r\n\r\n<p>Effective Java中文版</p>\r\n\r\n<p>Effective Java中文版</p>\r\n\r\n<p>Effective Java中文版</p>\r\n');
INSERT INTO `books` VALUES ('B20210331090820375', 'ISBN20210331090754', 'Java并发编程的艺术', 'C20210331090716316', 'upfiles/20210331090805.jpg', '林幸奇', 'Java并发编程的艺术', '是', '2021-05-09', 0, '10', 0, '<p>Java并发编程的艺术</p>\r\n');
INSERT INTO `books` VALUES ('B20210331090840822', 'ISBN20210331090820', 'Java并发编程实战', 'C20210331090716316', 'upfiles/20210331090827.jpg', '吴宛康', 'Java并发编程实战', '是', '2021-05-09', 0, '10', 0, '<p>Java并发编程实战</p>\r\n');
INSERT INTO `books` VALUES ('B20210331090907149', 'ISBN20210331090840', 'Java从入门到精通（第5版）', 'C20210331090716316', 'upfiles/20210331090850.jpg', '吴宛康', 'Java从', '是', '2021-05-09', 0, '10', 0, '<p>Java从入门到精通（第5版）Java从入门到精通（第5版）Java从入门到精通（第5版）Java从入门到精通（第5版）Java从入门到精通（第5版）</p>\r\n');
INSERT INTO `books` VALUES ('B20210331090930530', 'ISBN20210331090907', 'Java核心技术', 'C20210331090716316', 'upfiles/20210331090916.jpg', 'Java核心技术', 'Java核心技术', '是', '2021-05-09', 0, '9', 0, '<p>Java核心技术 卷I 基础知识</p>\r\n');
INSERT INTO `books` VALUES ('B20210406043641215', 'ISBN20210406043600', '蔡澜三部曲', 'C20210406043545788', 'upfiles/20210406043611.jpg', '蔡澜', '清华大学出版社', '是', '2021-05-09', 0, '5', 0, '<p>蔡澜三部曲：不如任性过生活+愿你成为最好的女子+今天也要好好吃饭（套装全3册）</p>\r\n');
INSERT INTO `books` VALUES ('B20210406043705326', 'ISBN20210406043641', '老舍全集', 'C20210406043545788', 'upfiles/20210406043652.jpg', '老舍', '清华大学出版社', '是', '2021-05-09', 0, '5', 0, '<p>老舍全集（1-19卷）（套装共19册）（修订版）</p>\r\n');
INSERT INTO `books` VALUES ('B20210406043733923', 'ISBN20210406043705', '鲁迅文学全集', 'C20210406043545788', 'upfiles/20210406043718.jpg', '鲁迅', '清华大学出版社', '是', '2021-05-09', 0, '5', 0, '<p>鲁迅文学全集（小说、杂文、散文、诗全集 套装全7册）</p>\r\n');
INSERT INTO `books` VALUES ('B20210406043757981', 'ISBN20210406043733', '你有多强大，就有多温柔', 'C20210406043545788', 'upfiles/20210406043741.jpg', '张三', '清华大学出版社', '是', '2021-05-09', 0, '5', 0, '<p>你有多强大，就有多温柔（附：书签）</p>\r\n');
INSERT INTO `books` VALUES ('B20210406043825133', 'ISBN20210406043757', '山川岁月长', 'C20210406043545788', 'upfiles/20210406043810.jpg', '蒋勋、龙应台', '清华大学出版社', '是', '2021-05-09', 0, '5', 0, '<p>山川岁月长（蒋勋、龙应台、林清玄等与一代人的对话）</p>\r\n');
COMMIT;

-- ----------------------------
-- Table structure for cate
-- ----------------------------
DROP TABLE IF EXISTS `cate`;
CREATE TABLE `cate` (
  `cateid` varchar(32) NOT NULL,
  `catename` varchar(50) DEFAULT NULL,
  `addtime` varchar(50) DEFAULT NULL,
  `memo` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`cateid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cate
-- ----------------------------
BEGIN;
INSERT INTO `cate` VALUES ('C20210331023300258', '小说', '2021-05-09', '小说');
INSERT INTO `cate` VALUES ('C20210331030740237', '英文原版', '2021-05-09', '英文原版');
INSERT INTO `cate` VALUES ('C20210331090716316', '计算机', '2021-05-09', '计算机科学与技术');
INSERT INTO `cate` VALUES ('C20210406043545788', '文学', '2021-05-09', '文学');
COMMIT;

-- ----------------------------
-- Table structure for complains
-- ----------------------------
DROP TABLE IF EXISTS `complains`;
CREATE TABLE `complains` (
  `complainsid` varchar(32) NOT NULL,
  `usersid` varchar(32) DEFAULT NULL,
  `title` varchar(50) DEFAULT NULL,
  `contents` varchar(50) DEFAULT NULL,
  `addtime` varchar(28) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `reps` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`complainsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of complains
-- ----------------------------
BEGIN;
INSERT INTO `complains` VALUES ('C20210331091245206', 'U20210331090943947', '态度特别好', '态度特别好', '2021-05-09', '已回复', '加油');
INSERT INTO `complains` VALUES ('C20210406044202226', 'U20210406043850769', '书籍全面，赞', '书籍全面，赞', '2021-05-09', '已回复', '感谢支持');
INSERT INTO `complains` VALUES ('C20210419133335542', 'U20210331090943947', '希望图书可以更多一点', '希望图书可以更多一点', '2021-05-09', '未回复', NULL);
COMMIT;

-- ----------------------------
-- Table structure for fav
-- ----------------------------
DROP TABLE IF EXISTS `fav`;
CREATE TABLE `fav` (
  `favid` varchar(32) NOT NULL,
  `usersid` varchar(32) DEFAULT NULL,
  `booksid` varchar(32) DEFAULT NULL,
  `addtime` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`favid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of fav
-- ----------------------------
BEGIN;
INSERT INTO `fav` VALUES ('F20210331091654532', 'U20210331090943947', 'B20210331090930530', '2021-05-09');
INSERT INTO `fav` VALUES ('F20210406043930955', 'U20210406043850769', 'B20210331090930530', '2021-05-09');
INSERT INTO `fav` VALUES ('F20210419133246942', 'U20210331090943947', 'B20210331090840822', '2021-05-09');
COMMIT;

-- ----------------------------
-- Table structure for orders
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `ordersid` varchar(32) NOT NULL,
  `ordercode` varchar(50) DEFAULT NULL,
  `usersid` varchar(32) DEFAULT NULL,
  `booksid` varchar(32) DEFAULT NULL,
  `thestart` varchar(50) DEFAULT NULL,
  `theend` varchar(50) DEFAULT NULL,
  `addtime` varchar(28) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `memo` varchar(50) DEFAULT NULL,
  `isdelay` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`ordersid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of orders
-- ----------------------------
BEGIN;
INSERT INTO `orders` VALUES ('O20210331031256366', 'BD20210331031256', 'U20210331031246815', 'B20210331031126440', '2021-05-09', '2021-05-09', '2021-05-09', '归还', NULL, NULL);
INSERT INTO `orders` VALUES ('O20210331091045760', 'BD20210331091045', 'U20210331090943947', 'B20210331090907149', '2021-05-09', '2021-05-09', '2021-05-09', '已评价', NULL, NULL);
INSERT INTO `orders` VALUES ('O20210331091052686', 'BD20210331091052', 'U20210331090943947', 'B20210331031106440', '2021-05-09', '2021-05-09', '2021-05-09', '已评价', NULL, NULL);
INSERT INTO `orders` VALUES ('O20210331091553352', 'BD20210331091553', 'U20210331090943947', 'B20210331090907149', '2021-05-09', '2021-05-09', '2021-05-09', '已评价', NULL, NULL);
INSERT INTO `orders` VALUES ('O20210331091555227', 'BD20210331091555', 'U20210331090943947', 'B20210331090820375', '2021-05-09', '2021-05-09', '2021-05-09', '已评价', NULL, NULL);
INSERT INTO `orders` VALUES ('O20210331091559708', 'BD20210331091559', 'U20210331090943947', 'B20210331025814921', '2021-05-09', '2021-05-09', '2021-05-09', '已评价', NULL, NULL);
INSERT INTO `orders` VALUES ('O20210331091601928', 'BD20210331091601', 'U20210331090943947', 'B20210331030836809', '2021-05-09', '2021-05-09', '2021-05-09', '已评价', NULL, NULL);
INSERT INTO `orders` VALUES ('O20210406031730639', 'BD20210406031730', 'U20210406031719347', 'B20210331090907149', '2021-05-09', '2021-05-09', '2021-05-09', '归还', NULL, '是');
INSERT INTO `orders` VALUES ('O20210406043914614', 'BD20210406043914', 'U20210406043850769', 'B20210406043825133', '2021-05-09', '2021-04-20', '2021-05-09', '已评价', NULL, '否');
INSERT INTO `orders` VALUES ('O20210406043920233', 'BD20210406043920', 'U20210406043850769', 'B20210331090930530', '2021-05-09', '2021-05-04', '2021-05-09', '借阅', NULL, '是');
INSERT INTO `orders` VALUES ('O20210419133253629', 'BD20210419133253', 'U20210331090943947', 'B20210331090820375', NULL, NULL, '2021-05-09', '预约', NULL, NULL);
INSERT INTO `orders` VALUES ('O20210419133303209', 'BD20210419133303', 'U20210331090943947', 'B20210331031106440', NULL, NULL, '2021-05-09', '预约', NULL, NULL);
COMMIT;

-- ----------------------------
-- Table structure for topic
-- ----------------------------
DROP TABLE IF EXISTS `topic`;
CREATE TABLE `topic` (
  `topicid` varchar(32) NOT NULL,
  `ordersid` varchar(32) DEFAULT NULL,
  `usersid` varchar(32) DEFAULT NULL,
  `booksid` varchar(32) DEFAULT NULL,
  `num` varchar(50) DEFAULT NULL,
  `contents` varchar(50) DEFAULT NULL,
  `addtime` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`topicid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of topic
-- ----------------------------
BEGIN;
INSERT INTO `topic` VALUES ('T20210331091210914', 'O20210331091045760', 'U20210331090943947', 'B20210331090907149', '5', '<p>内容精彩，推荐！</p>\r\n', '2021-05-09 09:12:10');
INSERT INTO `topic` VALUES ('T20210331091218171', 'O20210331091052686', 'U20210331090943947', 'B20210331031106440', '5', '<p>很好，赞</p>\r\n\r\n<p>发山东分公司大方</p>\r\n', '2021-05-09 09:12:18');
INSERT INTO `topic` VALUES ('T20210331091636457', 'O20210331091553352', 'U20210331090943947', 'B20210331090907149', '4', '<p>内容精彩，推荐！</p>\r\n', '2021-05-09 09:16:36');
INSERT INTO `topic` VALUES ('T20210331091641889', 'O20210331091555227', 'U20210331090943947', 'B20210331090820375', '4', '<p>很好，赞</p>', '2021-05-09 09:16:41');
INSERT INTO `topic` VALUES ('T20210331091646331', 'O20210331091559708', 'U20210331090943947', 'B20210331025814921', '3', '<p>内容精彩，推荐！</p>\r\n', '2021-05-09 09:16:46');
INSERT INTO `topic` VALUES ('T20210331091651902', 'O20210331091601928', 'U20210331090943947', 'B20210331030836809', '2', '<p>很好，赞</p>', '2021-05-09 09:16:51');
INSERT INTO `topic` VALUES ('T20210406044128407', 'O20210406043914614', 'U20210406043850769', 'B20210406043825133', '4', '<p>内容精彩，推荐！</p>\r\n', '2021-05-09 04:41:28');
COMMIT;

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `usersid` varchar(32) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `realname` varchar(50) DEFAULT NULL,
  `sex` varchar(10) DEFAULT NULL,
  `birthday` varchar(28) DEFAULT NULL,
  `contact` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `regdate` varchar(28) DEFAULT NULL,
  PRIMARY KEY (`usersid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of users
-- ----------------------------
BEGIN;
INSERT INTO `users` VALUES ('U20210331031246815', 'lisi', '123', '李四', '男', '2021-05-09', '123123', '解锁', '2021-05-09');
INSERT INTO `users` VALUES ('U20210331090943947', 'zhangsan', '123', '张三', '男', '1997-04-03', '13777777777', '解锁', '2021-05-09');
INSERT INTO `users` VALUES ('U20210406031719347', 'wangwu', '123', '王五', '男', '2021-05-09', '1111', '解锁', '2021-05-09');
INSERT INTO `users` VALUES ('U20210406043850769', 'zhaoliu', '123', '赵六', '男', '2021-05-09', '333', '解锁', '2021-05-09');
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
